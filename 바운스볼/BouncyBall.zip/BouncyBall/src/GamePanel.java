import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GamePanel extends JPanel implements ActionListener, KeyListener {

    public static final int TILE_SIZE = 32;

    private static final double GRAVITY = 0.5;
    private static final double MOVE_SPEED = 3.0;
    private static final double JUMP_POWER = -8.0;        // 일반 바운스 높이
    private static final double HIGH_JUMP_POWER = -10.2;  // 점프블럭용 높은 바운스
    private static final double MAX_FALL_SPEED = 12.0;

    private final Timer timer;

    private Level level;
    private Player player;

    private boolean leftPressed;
    private boolean rightPressed;

    public GamePanel() {
        level = Level.createSampleLevel();
        player = new Player(2 * TILE_SIZE, 5 * TILE_SIZE);

        int width = level.getCols() * TILE_SIZE;
        int height = level.getRows() * TILE_SIZE;

        setPreferredSize(new Dimension(width, height));
        setBackground(Color.WHITE);

        setFocusable(true);
        addKeyListener(this);

        timer = new Timer(16, this); // 약 60fps
        timer.start();
    }

    // ================= 게임 루프 =================

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        double vx = 0;

        // 좌우 이동
        if (leftPressed)  vx -= MOVE_SPEED;
        if (rightPressed) vx += MOVE_SPEED;

        // ★ 바닥(일반 블럭 위)에 있으면 자동 점프(바운스)
        //    점프블럭은 resolveCollisionsY()에서 HIGH_JUMP_POWER로 처리
        if (player.onGround && player.vy >= 0) {
            player.vy = JUMP_POWER;   // 위로 튕기기
            player.onGround = false;  // 이제 공중 상태
        }

        // 중력
        player.vy += GRAVITY;
        if (player.vy > MAX_FALL_SPEED) {
            player.vy = MAX_FALL_SPEED;
        }

        // 실제 이동
        movePlayer(vx, player.vy);
    }

    private void movePlayer(double vx, double vy) {
        // X 방향 이동
        player.x += vx;
        resolveCollisionsX();

        // Y 방향 이동
        player.y += vy;
        player.onGround = false;  // 일단 공중이라고 가정
        resolveCollisionsY();     // 바닥 / 점프블럭 / 가시와 충돌 시 상태 수정

        // 맵 아래(화면 아래쪽)에 닿으면 죽고 리셋
        int bottomLine = level.getRows() * TILE_SIZE;  // 화면 맨 아래 y좌표

        if (player.y + player.height >= bottomLine) {
            resetPlayer();
        }
    }

    // 플레이어 리셋 (죽었을 때 호출)
    private void resetPlayer() {
        player.x = 2 * TILE_SIZE;
        player.y = 5 * TILE_SIZE;
        player.vy = 0;
        player.onGround = false;
    }

    private void resolveCollisionsX() {
        Rectangle b = player.getBounds();
        int leftTile = b.x / TILE_SIZE;
        int rightTile = (b.x + b.width - 1) / TILE_SIZE;
        int topTile = b.y / TILE_SIZE;
        int bottomTile = (b.y + b.height - 1) / TILE_SIZE;

        for (int y = topTile; y <= bottomTile; y++) {
            for (int x = leftTile; x <= rightTile; x++) {
                TileType t = level.getTile(x, y);
                if (!t.isSolid()) continue;

                Rectangle tileRect = new Rectangle(
                        x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);

                if (b.intersects(tileRect)) {

                    // ★ 가시에 옆으로 부딪혀도 죽음
                    if (t == TileType.SPIKE) {
                        resetPlayer();
                        return; // 더 이상 충돌 처리 안 함
                    }

                    // 왼쪽에서 박은 경우
                    if (player.x + player.width / 2.0 < tileRect.x + TILE_SIZE / 2.0) {
                        player.x = tileRect.x - player.width;
                    } else { // 오른쪽에서 박은 경우
                        player.x = tileRect.x + TILE_SIZE;
                    }
                    b = player.getBounds();
                }
            }
        }
    }

    private void resolveCollisionsY() {
        Rectangle b = player.getBounds();
        int leftTile = b.x / TILE_SIZE;
        int rightTile = (b.x + b.width - 1) / TILE_SIZE;
        int topTile = b.y / TILE_SIZE;
        int bottomTile = (b.y + b.height - 1) / TILE_SIZE;

        for (int y = topTile; y <= bottomTile; y++) {
            for (int x = leftTile; x <= rightTile; x++) {
                TileType t = level.getTile(x, y);
                if (!t.isSolid()) continue;

                Rectangle tileRect = new Rectangle(
                        x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);

                if (b.intersects(tileRect)) {

                    // ★ 위/아래로 가시에 닿아도 즉시 죽음
                    if (t == TileType.SPIKE) {
                        resetPlayer();
                        return;
                    }

                    // 위에서 내려와서 바닥/블럭에 닿은 경우
                    if (player.y + player.height / 2.0 < tileRect.y + TILE_SIZE / 2.0) {
                        player.y = tileRect.y - player.height; // 발을 타일 위에 맞추기

                        if (t == TileType.JUMPBLOCK) {
                            // 점프블럭일 때: 바로 높은 점프로 튕김
                            player.vy = HIGH_JUMP_POWER;
                            player.onGround = false; // 계속 공중 상태
                        } else {
                            // 일반 블럭 / SPECIAL 위에서는 바닥에 서 있도록 처리
                            player.vy = 0;
                            player.onGround = true;
                        }
                    } else { // 아래에서 천장에 부딪힌 경우
                        player.y = tileRect.y + TILE_SIZE;
                        if (player.vy < 0) player.vy = 0;
                    }
                    b = player.getBounds();
                }
            }
        }
    }

    // ================= 그리기 =================

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // 연한 그리드
        g2.setColor(new Color(230, 230, 230));
        for (int x = 0; x <= level.getCols(); x++) {
            g2.drawLine(x * TILE_SIZE, 0, x * TILE_SIZE, getHeight());
        }
        for (int y = 0; y <= level.getRows(); y++) {
            g2.drawLine(0, y * TILE_SIZE, getWidth(), y * TILE_SIZE);
        }

        // 타일
        for (int y = 0; y < level.getRows(); y++) {
            for (int x = 0; x < level.getCols(); x++) {
                TileType t = level.getTile(x, y);
                int px = x * TILE_SIZE;
                int py = y * TILE_SIZE;

                switch (t) {
                    case BLOCK:
                    case SPECIAL:
                        g2.setColor(new Color(180, 180, 180));
                        g2.fillRect(px, py, TILE_SIZE, TILE_SIZE);
                        g2.setColor(Color.DARK_GRAY);
                        g2.drawRect(px, py, TILE_SIZE, TILE_SIZE);
                        break;

                    case JUMPBLOCK:
                        // 파란 점프 블럭
                        g2.setColor(new Color(80, 80, 255));
                        g2.fillRect(px, py, TILE_SIZE, TILE_SIZE);
                        g2.setColor(Color.BLUE.darker());
                        g2.drawRect(px, py, TILE_SIZE, TILE_SIZE);
                        break;

                    case SPIKE:
                        // 빨간 삼각형 가시
                        int cx = px + TILE_SIZE / 2;
                        int top = py + 4;
                        int left = px + 4;
                        int right = px + TILE_SIZE - 4;
                        int bottom = py + TILE_SIZE - 4;
                        int[] xs = { left, right, cx };
                        int[] ys = { bottom, bottom, top };

                        g2.setColor(Color.RED);
                        g2.fillPolygon(xs, ys, 3);
                        g2.setColor(Color.DARK_GRAY);
                        g2.drawPolygon(xs, ys, 3);
                        break;

                    case STAR:
                        g2.setColor(Color.YELLOW);
                        g2.fillOval(px + 8, py + 8, TILE_SIZE - 16, TILE_SIZE - 16);
                        g2.setColor(Color.ORANGE);
                        g2.drawOval(px + 8, py + 8, TILE_SIZE - 16, TILE_SIZE - 16);
                        break;

                    default:
                        // EMPTY는 안 그림
                        break;
                }
            }
        }

        // 플레이어
        player.draw(g2);
    }

    // ================= 키 입력 =================

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                leftPressed = true;
                break;
            case KeyEvent.VK_RIGHT:
                rightPressed = true;
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                leftPressed = false;
                break;
            case KeyEvent.VK_RIGHT:
                rightPressed = false;
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // 사용 안 함
    }
}
