public class Level {

    private final int cols;
    private final int rows;
    private final TileType[][] tiles;

    // ========== 생성자 : 문자열 배열(layout) → 타일 2차원 배열 ==========
    public Level(String[] layout) {
        this.rows = layout.length;
        this.cols = layout[0].length();
        this.tiles = new TileType[rows][cols];

        for (int y = 0; y < rows; y++) {
            String line = layout[y];
            for (int x = 0; x < cols; x++) {
                char c = line.charAt(x);
                tiles[y][x] = charToTile(c);
            }
        }
    }

    // 문자 -> 타일 타입 매핑
    private TileType charToTile(char c) {
        switch (c) {
            case '#': return TileType.BLOCK;      // 회색 블럭
            case '*': return TileType.STAR;       // 별
            case 'b': return TileType.SPECIAL;    // 점선 블럭
            case 'j': return TileType.JUMPBLOCK;  // 점프 블럭 (파란색)
            case 's': return TileType.SPIKE;      // 가시
            default:  return TileType.EMPTY;      // 나머지는 빈칸
        }
    }

    // (x, y) 위치 타일 가져오기
    public TileType getTile(int x, int y) {
        if (x < 0 || x >= cols || y < 0 || y >= rows) {
            // 맵 밖은 전부 벽 취급
            return TileType.BLOCK;
        }
        return tiles[y][x];
    }

    // 해당 위치가 충돌하는 타일인지?
    public boolean isSolid(int x, int y) {
        return getTile(x, y).isSolid();
    }

    public int getCols() {
        return cols;
    }

    public int getRows() {
        return rows;
    }

    // ==========  맵전체 구성도  ==========
    public static Level createSampleLevel() {
        String[] layout = {
            "..........................##",
            ".........................*##",
            "...............#*........###",
            "...............##.........##",
            "...........j...##....j....##",
            "...............##.........##",
            ".....###j#######...........#",
            "..........#*.........#j##..#",
            "..j.......####......#####..#",
            "..........#bbbsbbss######..#",
            "....j.....#bbbbbbbb######..#",
            "..........#........######..#",
            "#######j##........######***#",
            "##########........######***#",
            "##########........#######ss#"
        };
        return new Level(layout);
    }
}
