import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

// 공 캐릭터(플레이어)를 담당하는 클래스
//  - 위치(x, y)
//  - 속도(vx, vy)
//  - 크기(width, height)
//  - 바닥에 붙어 있는지(onGround)
public class Player {

    // 현재 위치 (왼쪽 위 기준)
    public double x, y;

    // 속도
    //  - vx : 좌우 이동 속도 (지금은 GamePanel에서 직접 x를 움직여서 잘 안 씀)
    //  - vy : 위/아래 속도 (점프, 낙하 등에 사용)
    public double vx, vy;

    // 공의 크기 (타일보다 조금 작은 16x16)
    public int width = 16;
    public int height = 16;

    // 바닥에 붙어 있는 상태인지 여부
    //  - true  : 발이 블럭 위에 딱 얹혀 있는 상태
    //  - false : 공중에 떠 있거나 떨어지는 중
    public boolean onGround = false;

    // 생성자: 시작 위치를 넘겨받아서 플레이어를 해당 좌표에 배치
    public Player(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // 현재 공의 충돌 영역(사각형)을 리턴
    //  - 충돌 체크는 보통 사각형 단위로 하기 때문에,
    //    화면에는 동그라미로 그려도, 계산은 Rectangle로 처리
    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, width, height);
    }

    // 화면에 플레이어 그리기
    //  - 노란색 동그라미 + 테두리
    //  - 여기서 외형만 담당 (움직임/물리는 GamePanel에서 처리)
    public void draw(Graphics2D g) {
        // 속이 찬 노란 공
        g.setColor(new Color(255, 215, 0)); // 골드빛 노랑
        g.fillOval((int) x, (int) y, width, height);

        // 약간 어두운 주황색으로 테두리
        g.setColor(Color.ORANGE.darker());
        g.drawOval((int) x, (int) y, width, height);
    }
}
