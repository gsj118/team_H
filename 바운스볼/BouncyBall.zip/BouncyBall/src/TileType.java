public enum TileType {
    EMPTY(false),    // 빈칸
    BLOCK(true),     // 회색 블럭
    STAR(false),     // 별
    SPECIAL(true),   // 점선 블럭 (충돌 있음)
    JUMPBLOCK(true), // 높은 점프하게 하는 블럭 (파란색)
	SPIKE(true); // 닿으면 죽는 가시

    private final boolean solid;

    TileType(boolean solid) {
        this.solid = solid;
    }

    public boolean isSolid() {
        return solid;
    }
}
